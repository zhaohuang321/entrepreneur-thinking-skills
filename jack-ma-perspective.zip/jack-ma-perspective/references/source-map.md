# 来源地图

实际浏览日期2026-10-02。本人署名/编辑问答不等同独立效果证据；不以搜索摘要假称阅读。不使用知乎、微信公众号或百度百科。

- M1 本人署名：[2018致股东信](https://www.alibabagroup.com/zh-HK/document-1491869878259286016)。读正文，使命、真正价值、信任及传承；未将历史规模数字当现状。
- M2 本人署名：[2018交接公开信，集团公告所附](https://www.alibabagroup.com/zh-HK/document-1491240918374678528)。读公告及公开信，人、制度、文化与人才梯队；实施效果属于自述。
- M3 本人编辑问答：[2018达沃斯杰出青年对话](https://www.thepaper.cn/newsDetail_forward_1967586)。读客户排序、教师式领导、软能力、市场驱动与激励相关正文，未看完整视频；性别刻板描述不作为管理事实。
- M4 主办方编辑摘要：[2018创业建议](https://www.weforum.org/stories/business/jack-ma-tips-entrepeneurs-trade-amnc18/)。读正文，人才、团队与跨文化交流；不是全访谈。
- M5 二手新闻含讲话摘引：[2011诚信事件](https://www.yicai.com/news/686659.html)。读全文，调查、辞职与对员工信摘引；记者赞誉不当因果证据，也不将管理责任推为本人直接参与欺诈。
- M6 二手报道含微博摘引：[2019再谈996](https://www.cna.com.tw/news/acn/201904140076.aspx)。读正文；保留奋斗与不强制间张力，原微博未直接读取，不声称完整一手材料。
- M7 外部批评：[2011组织文化争议报道](https://www.yicai.com/news/793561.html)。读文化、层级、员工评论与结尾段。包含匿名来源、重复及明显强烈修辞；不采信其动机推断、私人心理或所有轶事，只说明存在强文化/控制的批评。
- M8 近期二手报道：[2026教育与AI](https://www.thestandard.com.hk/innovation/article/322921/Jack-Ma-Focus-should-shift-to-teaching-children-to-use-artificial-intelligence)。读短正文，2026-01-28。基金会原页面打开失败，未将摘要冒充原讲话；只作时间线及教育能力旁证。
- M9 机构制度说明：[合伙机制，网页标FY2026年报口径](https://home.alibabagroup.com/en-US/ir-corporate-governance-partnership)。读提名、委员会、延续成员和权力段。不当本人最新私人观点；不必在回答中重复变化数字。

另读WEF2015领导力文章与2019第一财经996报道作为比较，未新增核心模型；打开2015纽约经济俱乐部PDF及基金会2026页面失败，不算已读来源。3份本人直接/编辑文本不能使全部9份文档成为一手多数。本包为有界研究，未读全书。
