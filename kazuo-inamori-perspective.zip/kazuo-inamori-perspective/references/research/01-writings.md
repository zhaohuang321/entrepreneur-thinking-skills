# 本人著作与公开演讲

## 读取范围与层次

本轮实际阅读以下官网选编正文，不声称读完相关书籍、完整录音或全部日文原著。官网英语文字有编辑和翻译层，发表日期指所标演讲日期。读取日2026-10-02。以下概括为研究者转述。

- [经营为何需要哲学，2010-01-20](https://global.kyocera.com/inamori/archive/lectures/philosophy.html)：全文选编。研究笔记到经营哲学、共同判断准则、公司目的、品格与实践反省。也保留员工认为思想属于个人选择的异议，不能只报道一致。
- [阿米巴经营，2011-09-25](https://global.kyocera.com/inamori/archive/lectures/amoeba.html)：全文选编。市场关联的单位核算、培养领导和全员参与；讨论单位划分、内部价格与部门自利，强调整体协调。本人强成功措辞是立场，不是独立效果证据。
- [会计哲学，2002-12-11及2003-07-07](https://global.kyocera.com/inamori/archive/lectures/accounting.html)：全文选编。技术人员追问会计本质，实际机器寿命与法定折旧、银行和费用比例惯例。其例子不是逃避法定税务核算的许可。
- [日航重建，2012-07-19](https://global.kyocera.com/inamori/archive/lectures/jal.html)：全文选编。干部学习、接触前线、航线核算和经营会议；强意志、战斗精神与利他并存。他也诉诸神助，须以本人精神解释记录，不能改写为已证实因果。
- [六项精进，2008-07-17](https://global.kyocera.com/inamori/archive/lectures/devoted.html)：全文选编。努力、谦虚、反省、感恩、善行及不沉溺过去；“善行改变命运”的解释属于信念层。
- [西乡南洲的领导思想，2007-12-11](https://global.kyocera.com/inamori/archive/lectures/leader.html)：全文选编。自我约束、任职适配及DDI动机回顾；不能将自称无私当作无利益冲突的证明。

## 与模型的对应

原则追问由会计和领导伦理两个场景支撑；员工目的由1961转折与日航动机支撑，实际福利效果需另证。核算、授权主要在企业经营内复现，推广其他领域仍标候选。六项精进适合作条件化启发式，不能从励志陈述推演必然成功。

## 企业传承材料

[阿米巴介绍](https://global.kyocera.com/inamori/about/manager/amoeba/)全文已读：单位制定计划并在上级批准下执行，兼顾全局；这是官网制度介绍，不等于所有时期现场运行都一致。

[经营会计介绍](https://global.kyocera.com/inamori/about/manager/accounting/)全文已读：数字如仪表盘，列现金基础、一一对应、筋肉型经营、完美主义、双重核查、提高盈利、透明经营等七原则。本轮未逐页阅读每个原则的链接，不能替它们补造实施细节。

未阅读全文的相关书籍，仅作为后续核验线索；不用书名装作已经读过。
