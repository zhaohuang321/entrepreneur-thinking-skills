# 松下幸之助来源地图
访问与核查日期：2026-10-02。以下页面已实际打开；仅使用说明的正文或摘要。不使用知乎、微信公众号或百度百科。

| ID | 实际打开的材料与URL | 类型、读取范围与限制 |
|---|---|---|
| K1 | [Mission of Business](https://holdings.panasonic/global/corporate/about/history/words-of-wisdom/missionofbusiness.html) | 本人著作英文节选；已读正文。由机构选编翻译，未核对应日文页码，非全书 |
| K2 | [Listen to People](https://holdings.panasonic/global/corporate/about/history/words-of-wisdom/listentopeople.html) | 本人著作英文节选；已读正文，倾听促进思考为本人判断，非控制实验 |
| K3 | [If We Trust People](https://holdings.panasonic/global/corporate/about/history/words-of-wisdom/ifwetrustpeople.html) | 本人著作英文节选；已读正文，信任与委派重要任务。不可把信任保证忠诚当实证规律 |
| K4 | [I Am the Cause](https://holdings.panasonic/global/corporate/about/history/words-of-wisdom/iamthecause.html) | 本人著作英文节选；已读正文，检视自身参与原因，同时并未否认外部因素 |
| K5 | [创设者致辞](https://www.php.co.jp/company/message.php) | 本人署名材料，1987年4月；实际读正文76—90行。智慧汇聚、物心繁荣与未来使命。现代机构导航不算本人文字 |
| K6 | [任せて任せず](https://konosuke-matsushita.com/keywords/hr-development/no3.php) | PHP机构用语解说，实际读17—18行；不是本人逐字讲话，病床听报告等叙述未独立核实 |
| K7 | [1933历史](https://holdings.panasonic/global/corporate/about/history/chronicle/1933.html)及[银行账户故事](https://holdings.panasonic/jp/corporate/about/history/founders-story/4-3.html) | 企业历史/叙事，二手；读事业部、1927委派及权限责任情节。故事中的重构对话不当逐字档案 |
| K8 | [1964热海会议](https://holdings.panasonic/global/corporate/about/history/chronicle/1964.html) | 企业历史，含转引讲话；读会议分歧及承认自身失败。不能把“各半”当精确因果分摊 |
| K9 | [1965改革与五日工作制](https://holdings.panasonic/global/corporate/about/history/chronicle/1965.html) | 企业历史，二手；读销售制度改革及五日制段落，成功归因有纪念宣传目的 |
| K10 | [现行自主责任](https://holdings.panasonic/global/corporate/about/philosophy/8.html)、[集众智](https://holdings.panasonic/global/corporate/about/philosophy/9.html)、[培养人](https://holdings.panasonic/global/corporate/about/philosophy/10.html) | 2021后修订的机构经营方针，混合历史引语和当代解释；实际读正文。不能把全部段落说成松下本人原话，佐贺工厂例子是高桥荒太郎行动 |
| K11 | [Nigel Holden，2001](https://journals.sagepub.com/doi/10.1177/147059580111007) | 外部学术批评，实际读公开摘要；谈保守文化与海外本地经理授权张力，未读付费全文，2001不能算松下本人当时决策 |
| K12 | [Hatch与Yamamura：The Labor Network](https://www.cambridge.org/core/books/abs/asia-in-japans-embrace/labor-network/91F7EF81DF739F8D3097C8D31208A00A) | 外部学术研究；1996书，2012上线；实际读Summary可见段，非全章。描述海外公司仪式、家长主义安排，不能证明全体员工经验 |
| K13 | [PHP：衆知を集める](https://www.php.co.jp/think/shuchi.php) | 机构解释混合引语；实际读正文75—87行，原讲话日期/书籍页码未充分追溯，降权旁证 |
| K14 | [官方节选总目录](https://holdings.panasonic/global/corporate/about/history/words-of-wisdom.html)及[人物历史](https://holdings.panasonic/global/corporate/about/history.html) | 机构出处和人物资料；已读书名说明与人物简介。K1—K4来自Omoumama与Matsushita Konosuke Ichinichi Ichiwa所选内容，未确定每篇对应哪本的日文页码 |


## 主张映射
- 使命：K1、K5；多方渠道条件旁证K9。
- 任事育人：K2、K3、K7；现代说明K10不得冒充本人全部文字。
- 任せて任せず：K6、K7、K9；术语证据是机构解释，强度较低。
- 集众智与自省：K2、K4、K5、K8、K13；自省不是全责推定。
- 家长主义与海外权力：K11摘要、K12可见Summary，未读全部学术材料。

## 质量与缺口
本人直接正文来自K1—K5；K1—K4为同一官方选编体系，不是四个独立证人。其他是机构解释、企业史、外部研究或书目，不能利用混合引语将整个页面升级为本人一手。按严格条目计一手大于50%门槛未达，保留有界交付。逐篇日文出处、长对话、私人决策及员工经历仍薄弱。模型应用和Konbuild流程均是本项目转译。
