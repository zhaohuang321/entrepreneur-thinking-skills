# 来源地图与本次更新

截止2026-10-05。P本人公开表达；E外部研究；B书目。旧包备份在整批交付目录backups，用户调用不依赖备份。

|编号|来源|实际读取与限制|
|---|---|---|
|S1 P|[海尔2017演讲整理](https://www.haier.com/about-haier/founder/speech/20170926_130439.shtml)|2017-09-20演讲，09-26发布；读取酒柜、平台三权、第二曲线、跨文化关键段。页面说明录音整理、未本人确认、删节，不能假称完整授权原稿|
|S2 P|[海尔2020工业互联网公开发言](https://www.haier.com/about-haier/founder/speech/20200629_139462.shtml)|2020-06-29页面；读取阳台场景、链群及价值创造分享段；效果是企业自述|
|S3 P|[沃顿2018编辑访谈](https://knowledge.wharton.upenn.edu/podcast/knowledge-at-wharton-podcast/haiers-zhang-ruimin-success-means-creating-the-future/)|2018-04-20全文网页问答；未听45分钟音频；中层、小试点及未抓住电商机会仅是当时回顾|
|S4 P|[麦肯锡2021编辑访谈](https://www.mckinsey.com/capabilities/people-and-organization/our-insights/shattering-the-status-quo-a-conversation-with-haiers-zhang-ruimin)|2021-07-27网页问答关键段，设计者、体验、移动互联网反思；未读附录PDF或视频|
|S5 E|[Frynas/Mol/Mellahi：Management Innovation Made in China，作者稿](https://research-api.cbs.dk/ws/portalfiles/portal/57758021/michael_j_mol_et_al_management_innovation_made_in_china_acceptedmanuscript.pdf)|2018论文，共37页；本轮读取文本中领导、制度、资源与跨情境限制选段，非整篇通读；不是员工全面调查或2026法律依据|
|B1 B|[出版社《永恒的活火》书目](https://www.zcycjy.com/readBooks?bookCde=9787522322056&switChover=1)|2023-12-01出版，张瑞敏署名；只核元数据，未读完整原书|
|B2 B/E|[三民同书目录及试阅](https://www.sanmin.com.tw/product/index/012974309)|ISBN9787522322056，目录和朱宏任推荐序；不是张瑞敏本人正文。关于对话数量、宣传成绩不独立核验|

模型1=S1/S2/S4；模型2=S1/S2/S3；模型3=S2/S4/S5。B1和B2是同一本书的元数据与序言，不当两份独立本人思想证据。

排除审计：旧版S6（海尔2025-09-22转载、来源青报观象山）不保留为核心证据；新浪2026-06-10文章标明公众号来源，也排除。掌阅页面打开失败，不登记为正文已读。近期窗口2025-10-05—2026-10-05内，未获得合格本人思想长文，保留这一缺口。

这次更新将旧版四个模型中的平台和变革合为一个，保留其情境差异；理由是证据深度不足以声称完整思维操作系统，而非认定本人只有三个模型。
